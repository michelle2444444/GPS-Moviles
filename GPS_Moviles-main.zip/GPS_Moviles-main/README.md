# GPS_Moviles

FUNCIONAMIENTO

![IMG-20250515-WA0096](https://github.com/user-attachments/assets/ed789a67-44d5-409c-ada5-c2a2c6c18e80)

![IMG-20250515-WA0097](https://github.com/user-attachments/assets/746b8c43-d7df-43aa-b364-dd177f6817c5)

![IMG-20250515-WA0095](https://github.com/user-attachments/assets/f0d50b0a-8fa8-4c95-877b-35110a9ed110)

![IMG-20250515-WA0094](https://github.com/user-attachments/assets/e47c485d-e1c8-49b6-a4f6-ac80dab213a9)



