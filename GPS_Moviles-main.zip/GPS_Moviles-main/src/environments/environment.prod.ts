export const environment = {
  production: false,
  firebaseConfig: {
  apiKey: "TusCredenciales",
  authDomain: "TusCredenciales",
  projectId: "TusCredenciales",
  storageBucket: "TusCredenciales",
  messagingSenderId: "TusCredenciales",
  appId: "TusCredenciales",
  measurementId: "TusCredenciales"
  }
};
