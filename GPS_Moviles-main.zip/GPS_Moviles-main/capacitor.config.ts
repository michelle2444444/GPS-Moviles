import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'gps.app',
  appName: 'MIGPS',
  webDir: 'www'
};

export default config;
